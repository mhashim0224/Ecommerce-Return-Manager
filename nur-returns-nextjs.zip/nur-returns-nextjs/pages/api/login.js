import { serialize } from "cookie";

export default function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const { password } = req.body;

  if (password !== process.env.APP_PASSWORD) {
    return res.status(401).json({ error: "Wrong password" });
  }

  // Set auth cookie valid for 7 days
  const cookie = serialize("auth", password, {
    httpOnly: true,
    secure:   process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge:   60 * 60 * 24 * 7,
    path:     "/",
  });

  res.setHeader("Set-Cookie", cookie);
  res.json({ ok: true });
}
